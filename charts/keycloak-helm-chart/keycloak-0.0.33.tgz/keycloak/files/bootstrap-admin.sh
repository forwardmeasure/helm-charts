#!/usr/bin/env sh
set -eu

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

log() {
  printf '%s INFO  %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >&2
}

log_section() {
  printf '%s ----- %s -----\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >&2
}

# Ends the whole Job, also from inside a command substitution or a pipeline
# stage. Those run in subshells, where a bare exit ends only the subshell and
# the caller carries on with an empty value (e.g. a failed client lookup read
# as "client does not exist"). start_job_session records the Job's own shell.
fail() {
  printf '%s ERROR %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*" >&2
  if [ -n "${KC_JOB_PID:-}" ]; then
    kill -TERM "$KC_JOB_PID" 2>/dev/null || true
  fi
  exit 1
}

require_env() {
  var="$1"
  eval "val=\${$var:-}"
  [ -n "$val" ] || fail "Required env var '$var' is not set"
}

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

json_escape() {
  printf '%s' "$1" | jq -R .
}

# ---------------------------------------------------------------------------
# Admin REST session
#
# The Job logs in as the master-realm administrator through admin-cli. The
# master realm issues those access tokens for about a minute, far less than
# reconciling every service client takes, so no call uses a token it holds
# from the start: each Admin REST call goes through kc_request, which renews
# the token before it expires (from the login's own expires_in, with a margin)
# and, should Keycloak still answer 401, renews it and sends that one call
# again, within the platform's dependency-retry setting (attempts and back-off,
# below). A 401 on the last attempt fails the Job like any other unexpected
# status.
#
# The token and its renewal time live in files in a private session directory,
# not in shell variables: most calls run in command substitutions, and a token
# renewed in a subshell must be what the caller uses next. Tokens, passwords,
# and request bodies never appear on a command line (curl reads them from a
# file or standard input) and never in the log (response bodies are redacted).
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# The platform's dependency-retry setting
#
# The variables every service reads (forwardmeasure-platform DependencyRetry),
# with the same defaults and rules: FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS
# (a whole number, at least 1; 10), _INITIAL_BACKOFF and _MAXIMUM_BACKOFF
# (ISO-8601 durations, at least zero and at least the initial; PT1S, PT1M),
# _MULTIPLIER (a number, at least 1; 2), _JITTER (0 to 1; 0.2: each wait drawn
# from (1 - jitter) of it up to it) and _CONNECT_TIMEOUT (an ISO-8601 duration
# longer than zero; PT30S: opening one connection). The chart renders them from
# its dependencyRetry value, which the release fills from the shared
# platform.dependencyRetry. A value the script cannot use stops the Job at
# start, naming the variable.
# ---------------------------------------------------------------------------

# kc_duration_seconds NAME VALUE: an ISO-8601 duration (PnDTnHnMn.nS) in seconds.
kc_duration_seconds() {
  kc_duration="$(printf '%s' "$2" | jq -Rr '
    ascii_upcase as $value
    | "^P(?:(?<d>[0-9]+)D)?(?:T(?=[0-9])(?:(?<h>[0-9]+)H)?(?:(?<m>[0-9]+)M)?(?:(?<s>[0-9]+(?:\\.[0-9]{1,9})?)S)?)?$" as $form
    | if ($value | test($form)) and ($value | test("[0-9]")) then
        $value | capture($form)
        | ((.d // "0" | tonumber) * 86400 + (.h // "0" | tonumber) * 3600
           + (.m // "0" | tonumber) * 60 + (.s // "0" | tonumber))
      else error("not an ISO-8601 duration") end' 2>/dev/null)" \
    || fail "$1 must be an ISO-8601 duration such as PT1S, not '$2'"
  printf '%s' "$kc_duration"
}

# kc_compare A OP B: true when the decimal numbers compare so (OP: ge, gt, le).
kc_compare() {
  awk -v a="$1" -v b="$3" -v op="$2" 'BEGIN {
    if (op == "ge") exit !(a + 0 >= b + 0)
    if (op == "gt") exit !(a + 0 > b + 0)
    exit !(a + 0 <= b + 0) }'
}

kc_decimal() {
  printf '%s' "$1" | grep -Eq '^[0-9]+(\.[0-9]+)?$'
}

kc_read_retry_setting() {
  KC_RETRY_ATTEMPTS="${FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS:-10}"
  case "$KC_RETRY_ATTEMPTS" in
    '' | *[!0-9]*) fail "FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS must be a whole number of at least 1, not '${KC_RETRY_ATTEMPTS}'" ;;
  esac
  [ "$KC_RETRY_ATTEMPTS" -ge 1 ] \
    || fail "FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS must be a whole number of at least 1, not '${KC_RETRY_ATTEMPTS}'"
  KC_RETRY_INITIAL_SECONDS="$(kc_duration_seconds FORWARDMEASURE_DEPENDENCY_RETRY_INITIAL_BACKOFF \
    "${FORWARDMEASURE_DEPENDENCY_RETRY_INITIAL_BACKOFF:-PT1S}")" || exit 1
  KC_RETRY_MAXIMUM_SECONDS="$(kc_duration_seconds FORWARDMEASURE_DEPENDENCY_RETRY_MAXIMUM_BACKOFF \
    "${FORWARDMEASURE_DEPENDENCY_RETRY_MAXIMUM_BACKOFF:-PT1M}")" || exit 1
  kc_compare "$KC_RETRY_MAXIMUM_SECONDS" ge "$KC_RETRY_INITIAL_SECONDS" \
    || fail "FORWARDMEASURE_DEPENDENCY_RETRY_MAXIMUM_BACKOFF must be at least the initial back-off (${KC_RETRY_INITIAL_SECONDS}s), not '${FORWARDMEASURE_DEPENDENCY_RETRY_MAXIMUM_BACKOFF:-PT1M}'"
  KC_RETRY_MULTIPLIER="${FORWARDMEASURE_DEPENDENCY_RETRY_MULTIPLIER:-2}"
  { kc_decimal "$KC_RETRY_MULTIPLIER" && kc_compare "$KC_RETRY_MULTIPLIER" ge 1; } \
    || fail "FORWARDMEASURE_DEPENDENCY_RETRY_MULTIPLIER must be a number of at least 1, not '${KC_RETRY_MULTIPLIER}'"
  KC_RETRY_JITTER="${FORWARDMEASURE_DEPENDENCY_RETRY_JITTER:-0.2}"
  { kc_decimal "$KC_RETRY_JITTER" && kc_compare "$KC_RETRY_JITTER" le 1; } \
    || fail "FORWARDMEASURE_DEPENDENCY_RETRY_JITTER must be a fraction from 0 to 1, not '${KC_RETRY_JITTER}'"
  KC_CONNECT_TIMEOUT_SECONDS="$(kc_duration_seconds FORWARDMEASURE_DEPENDENCY_RETRY_CONNECT_TIMEOUT \
    "${FORWARDMEASURE_DEPENDENCY_RETRY_CONNECT_TIMEOUT:-PT30S}")" || exit 1
  kc_compare "$KC_CONNECT_TIMEOUT_SECONDS" gt 0 \
    || fail "FORWARDMEASURE_DEPENDENCY_RETRY_CONNECT_TIMEOUT must be longer than zero, not '${FORWARDMEASURE_DEPENDENCY_RETRY_CONNECT_TIMEOUT}'"
  KC_RETRY_READ=1
  export KC_RETRY_ATTEMPTS KC_RETRY_INITIAL_SECONDS KC_RETRY_MAXIMUM_SECONDS KC_RETRY_MULTIPLIER \
    KC_RETRY_JITTER KC_CONNECT_TIMEOUT_SECONDS KC_RETRY_READ
}

kc_require_retry_setting() {
  [ -n "${KC_RETRY_READ:-}" ] || kc_read_retry_setting
}

# kc_retry_wait N: the seconds to wait after failed attempt N (the first is 1)
# before the next: the initial back-off, multiplied for each attempt after the
# first, at most the maximum, then up to the jitter of it shorter at random.
kc_retry_wait() {
  awk -v n="$1" -v initial="$KC_RETRY_INITIAL_SECONDS" -v maximum="$KC_RETRY_MAXIMUM_SECONDS" \
    -v multiplier="$KC_RETRY_MULTIPLIER" -v jitter="$KC_RETRY_JITTER" -v seed="$(date -u +%s)$$$1" 'BEGIN {
      wait = initial
      for (i = 1; i < n && wait < maximum; i++) wait *= multiplier
      if (wait > maximum) wait = maximum
      srand(seed)
      printf "%.3f", wait - wait * jitter * rand() }'
}

start_job_session() {
  KC_JOB_PID=$$
  trap 'exit 1' TERM INT
  KC_SESSION_DIR="$(mktemp -d)" || fail "Could not create a private directory for the admin session"
  chmod 700 "$KC_SESSION_DIR"
  trap 'rm -rf "$KC_SESSION_DIR"' EXIT
  export KC_JOB_PID KC_SESSION_DIR
}

kc_epoch_seconds() {
  date -u +%s
}

# Prints a response body for the log: JSON with every token, secret, password,
# or credential value replaced, anything else cut to 2000 bytes on one line.
kc_redacted_body() {
  if [ ! -s "$1" ]; then
    printf '%s' '<empty body>'
  elif jq empty "$1" >/dev/null 2>&1; then
    jq -c 'walk(if type == "object" then with_entries(
        if (.key | test("token|secret|password|credential|assertion"; "i"))
        then .value = "<redacted>" else . end) else . end)' "$1"
  else
    head -c 2000 "$1" | tr '\n\r' '  ' \
      | sed -E 's/(token|secret|password|credential|assertion)([^A-Za-z0-9<]{1,4})[^&" ,;<]+/\1\2<redacted>/Ig'
  fi
}

kc_admin_login() {
  kc_login_url="${KEYCLOAK_URL}/realms/master/protocol/openid-connect/token"
  kc_login_call="POST ${kc_login_url} (admin login as ${KEYCLOAK_ADMIN})"
  kc_login_response="$(mktemp "${KC_SESSION_DIR}/login.XXXXXX")"
  kc_login_requested_at="$(kc_epoch_seconds)"
  kc_login_rc=0
  kc_require_retry_setting
  kc_login_status="$(printf '%s' "${KEYCLOAK_ADMIN_PASSWORD}" | curl -sS \
    --connect-timeout "$KC_CONNECT_TIMEOUT_SECONDS" \
    -o "$kc_login_response" -w '%{http_code}' \
    -X POST "$kc_login_url" \
    --data-urlencode "grant_type=password" \
    --data-urlencode "client_id=admin-cli" \
    --data-urlencode "username=${KEYCLOAK_ADMIN}" \
    --data-urlencode "password@-")" || kc_login_rc=$?
  [ "$kc_login_rc" -eq 0 ] || fail "${kc_login_call} could not reach Keycloak (curl exit ${kc_login_rc})"
  if [ "$kc_login_status" != "200" ]; then
    fail "${kc_login_call} -> HTTP ${kc_login_status}: $(kc_redacted_body "$kc_login_response")"
  fi
  kc_login_expires_in="$(jq -er '.expires_in | select(type == "number" and . >= 1) | floor' "$kc_login_response")" \
    || fail "${kc_login_call} -> HTTP 200 without a positive expires_in: $(kc_redacted_body "$kc_login_response")"
  kc_login_header="$(mktemp "${KC_SESSION_DIR}/authorization.XXXXXX")"
  jq -er '.access_token | select(type == "string" and length > 0) | "Authorization: Bearer " + .' \
    "$kc_login_response" > "$kc_login_header" \
    || fail "${kc_login_call} -> HTTP 200 without an access_token: $(kc_redacted_body "$kc_login_response")"
  rm -f "$kc_login_response"
  # Renew a quarter of the lifetime early, at most 15 seconds: a call never
  # starts with a token about to lapse, and a minute-long token lasts 45s.
  kc_login_margin=$((kc_login_expires_in / 4))
  [ "$kc_login_margin" -le 15 ] || kc_login_margin=15
  printf '%s\n' "$((kc_login_requested_at + kc_login_expires_in - kc_login_margin))" \
    > "${KC_SESSION_DIR}/renew-at.next"
  mv -f "${KC_SESSION_DIR}/renew-at.next" "${KC_SESSION_DIR}/renew-at"
  mv -f "$kc_login_header" "${KC_SESSION_DIR}/authorization"
  log "Admin access token obtained (lifetime ${kc_login_expires_in}s; renewed ${kc_login_margin}s before it expires)"
}

kc_ensure_admin_token() {
  [ -n "${KC_SESSION_DIR:-}" ] || fail "Admin REST call before start_job_session"
  if [ -s "${KC_SESSION_DIR}/authorization" ] && [ -s "${KC_SESSION_DIR}/renew-at" ]; then
    if [ "$(kc_epoch_seconds)" -lt "$(cat "${KC_SESSION_DIR}/renew-at")" ]; then
      return 0
    fi
    log "Admin access token is due for renewal - logging in again"
  fi
  kc_admin_login
}

# kc_send METHOD URL [JSON_BODY]: one HTTP exchange with the current token.
# Sets KC_STATUS and KC_RESPONSE (a file the caller removes).
kc_send() {
  kc_require_retry_setting
  KC_RESPONSE="$(mktemp "${KC_SESSION_DIR}/response.XXXXXX")"
  kc_send_rc=0
  if [ "$#" -ge 3 ]; then
    KC_STATUS="$(printf '%s' "$3" | curl -sS --connect-timeout "$KC_CONNECT_TIMEOUT_SECONDS" \
      -o "$KC_RESPONSE" -w '%{http_code}' \
      -X "$1" \
      -H "@${KC_SESSION_DIR}/authorization" \
      -H "Content-Type: application/json" \
      --data-binary @- \
      "$2")" || kc_send_rc=$?
  else
    KC_STATUS="$(curl -sS --connect-timeout "$KC_CONNECT_TIMEOUT_SECONDS" \
      -o "$KC_RESPONSE" -w '%{http_code}' \
      -X "$1" \
      -H "@${KC_SESSION_DIR}/authorization" \
      "$2")" || kc_send_rc=$?
  fi
  if [ "$kc_send_rc" -ne 0 ]; then
    rm -f "$KC_RESPONSE"
    fail "$1 $2 could not reach Keycloak (curl exit ${kc_send_rc})"
  fi
}

# kc_request METHOD URL [JSON_BODY]: kc_send with a token that is renewed
# before it expires; on a 401 the token is renewed and the call sent again,
# up to FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS sends in all, with the
# setting's back-off between them. The last answer is the caller's.
kc_request() {
  kc_require_retry_setting
  kc_ensure_admin_token
  kc_send "$@"
  kc_request_attempt=1
  while [ "$KC_STATUS" = "401" ] && [ "$kc_request_attempt" -lt "$KC_RETRY_ATTEMPTS" ]; do
    kc_request_wait="$(kc_retry_wait "$kc_request_attempt")"
    log "$1 $2 -> HTTP 401 (attempt ${kc_request_attempt} of ${KC_RETRY_ATTEMPTS}): $(kc_redacted_body "$KC_RESPONSE") - renewing the admin token and sending this call again in ${kc_request_wait}s"
    rm -f "$KC_RESPONSE"
    sleep "$kc_request_wait"
    kc_admin_login
    kc_send "$@"
    kc_request_attempt=$((kc_request_attempt + 1))
  done
}

# kc_await_user_id LOOKUP USERNAME: sets KC_AWAITED_ID to the id of a user just
# created, looked up with the function LOOKUP, up to
# FORWARDMEASURE_DEPENDENCY_RETRY_ATTEMPTS lookups with the setting's back-off
# between them; after the last the Job fails, naming the user.
kc_await_user_id() {
  kc_require_retry_setting
  kc_await_attempt=1
  while :; do
    KC_AWAITED_ID="$("$1" "$2" || true)"
    [ -z "$KC_AWAITED_ID" ] || return 0
    [ "$kc_await_attempt" -lt "$KC_RETRY_ATTEMPTS" ] \
      || fail "User POST succeeded but '$2' not found after ${kc_await_attempt} attempts"
    kc_await_wait="$(kc_retry_wait "$kc_await_attempt")"
    log "User '$2' not yet queryable (attempt ${kc_await_attempt} of ${KC_RETRY_ATTEMPTS}) — looking again in ${kc_await_wait}s"
    sleep "$kc_await_wait"
    kc_await_attempt=$((kc_await_attempt + 1))
  done
}

# kc_call "ACCEPTED STATUSES" METHOD URL [JSON_BODY]: any other status ends the
# Job with the call, the status, and Keycloak's (redacted) response body.
kc_call() {
  kc_call_accepted="$1"
  shift
  kc_request "$@"
  case " ${kc_call_accepted} " in
    *" ${KC_STATUS} "*) ;;
    *)
      kc_call_detail="$(kc_redacted_body "$KC_RESPONSE")"
      rm -f "$KC_RESPONSE"
      fail "$1 $2 -> HTTP ${KC_STATUS}: ${kc_call_detail}"
      ;;
  esac
}

kc_get() {
  kc_call "200" GET "$1"
  cat "$KC_RESPONSE"
  rm -f "$KC_RESPONSE"
}

kc_post_json() {
  kc_call "201 204 409" POST "$1" "$2"
  rm -f "$KC_RESPONSE"
  if [ "$KC_STATUS" = "409" ]; then
    log "POST $1 returned 409 (already exists) — skipping"
  fi
}

kc_put_json() {
  kc_call "204" PUT "$1" "$2"
  rm -f "$KC_RESPONSE"
}

kc_put_no_body() {
  kc_call "204" PUT "$1"
  rm -f "$KC_RESPONSE"
}

kc_delete_json() {
  kc_call "204" DELETE "$1" "$2"
  rm -f "$KC_RESPONSE"
}

kc_delete_no_body() {
  kc_call "204" DELETE "$1"
  rm -f "$KC_RESPONSE"
}

# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------

print_config_banner() {
  log_section "Bootstrap configuration"
  log "KEYCLOAK_URL                            = ${KEYCLOAK_URL}"
  log "REALM                                   = ${REALM}"
  log "REALM_LOGIN_THEME                       = ${REALM_LOGIN_THEME}"
  log "KEYCLOAK_ADMIN                          = ${KEYCLOAK_ADMIN}"
  log "ADMIN_USERNAME                          = ${ADMIN_USERNAME}"
  log "ADMIN_EMAIL                             = ${ADMIN_EMAIL}"
  log "ADMIN_FIRST_NAME                        = ${ADMIN_FIRST_NAME}"
  log "ADMIN_LAST_NAME                         = ${ADMIN_LAST_NAME}"
  log "ADMIN_TENANT_DID                        = ${ADMIN_TENANT_DID}"
  log "ADMIN_ACTOR_DID                         = ${ADMIN_ACTOR_DID}"
  log "ADMIN_ACTOR_TYPE                        = ${ADMIN_ACTOR_TYPE}"
  log "FORWARDMEASURE_ROLE_VIEWER                  = ${FORWARDMEASURE_ROLE_VIEWER}"
  log "FORWARDMEASURE_ROLE_ACCESS_ADMIN            = ${FORWARDMEASURE_ROLE_ACCESS_ADMIN}"
  log "FORWARDMEASURE_ROLE_PLATFORM_ADMIN          = ${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}"
  log "FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID = ${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}"
  log "FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID       = ${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}"
  log "FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_REDIRECT_URIS_JSON = ${FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_REDIRECT_URIS_JSON}"
  log "FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_WEB_ORIGINS_JSON   = ${FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_WEB_ORIGINS_JSON}"
  log "KEYCLOAK_REALM_MGMT_ROLES               = ${KEYCLOAK_REALM_MGMT_ROLES}"
  log "FORWARDMEASURE_TENANT_GROUP_ROLES           = ${FORWARDMEASURE_TENANT_GROUP_ROLES:-<empty>}"
  log "KEYCLOAK_READY_SLEEP_SECONDS            = ${KEYCLOAK_READY_SLEEP_SECONDS}"
  log "Dependency retry                        = ${KC_RETRY_ATTEMPTS} attempts, back-off ${KC_RETRY_INITIAL_SECONDS}s x ${KC_RETRY_MULTIPLIER} up to ${KC_RETRY_MAXIMUM_SECONDS}s (jitter ${KC_RETRY_JITTER}), connect timeout ${KC_CONNECT_TIMEOUT_SECONDS}s"
  log_section "Starting bootstrap"
}

configure_realm_theme() {
  log_section "Realm theme configuration"
  body="$(jq -n --arg login_theme "${REALM_LOGIN_THEME}" --arg display_name "${REALM_DISPLAY_NAME:-${REALM}}" \
    '{loginTheme: $login_theme, displayName: $display_name, displayNameHtml: null}')"
  kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}" "$body"
  log "Realm login theme reconciled: ${REALM_LOGIN_THEME}"
}

# Every realm has used Keycloak's declarative User Profile since 24.x,
# whether or not it's ever explicitly configured (this realm's own import
# JSON has no UserProfileProvider component at all, so it runs on whatever
# Keycloak's own default is). Left unset, that default silently DROPS any
# attribute not declared in the profile's own schema on write - the request
# itself still succeeds (kc_put_json below sees the same 204 it always
# does), it just never persists. Confirmed the hard way: create_or_update_
# bootstrap_user's PUT to set tenant_did/actor_did/actor_type reported
# success on every run, but a real issued token never once carried any of
# the three - the forwardmeasure_identity scope's mappers had nothing to
# map. GET-then-PUT, not a blind PUT: the current config's own declared
# attributes/groups (Keycloak's built-in username/email/firstName/lastName
# schema) must survive this, only unmanagedAttributePolicy is being added.
configure_user_profile_unmanaged_attributes() {
  log_section "User profile: allow unmanaged attributes and two-letter usernames"
  current="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users/profile")"
  # Keycloak's default username length is 3..255, which rejects a person's
  # initials (a tenant administrator "pn" failed with error-invalid-length).
  # Only the minimum changes; the maximum and the character rules stay.
  body="$(printf '%s' "$current" | jq '
    .unmanagedAttributePolicy = "ENABLED"
    | (.attributes[]? | select(.name == "username" and .validations.length != null)
        | .validations.length.min) = 2')"
  # Not kc_put_json: that helper requires a bare 204, which matches
  # resource-style endpoints (e.g. the user PUT below) but not this one -
  # PUT .../users/profile is a configuration-object endpoint and Keycloak's
  # admin REST API conventionally returns 200 with the updated
  # representation for that shape of endpoint, not 204. The first version
  # of this function used kc_put_json here and the Job failed - the pod
  # was garbage-collected before its logs could be read to confirm the
  # exact status code, so this accepts either rather than guessing which
  # one it actually was.
  kc_call "200 204" PUT "${KEYCLOAK_URL}/admin/realms/${REALM}/users/profile" "$body"
  rm -f "$KC_RESPONSE"
  log "User profile now allows unmanaged attributes (tenant_did/actor_did/actor_type) and two-letter usernames"
}

# ---------------------------------------------------------------------------
# Keycloak readiness
# ---------------------------------------------------------------------------

wait_for_keycloak() {
  log "Polling ${KEYCLOAK_URL}/realms/${REALM} ..."
  attempt=1
  kc_require_retry_setting
  while :; do
    http_code="$(curl -sS --connect-timeout "$KC_CONNECT_TIMEOUT_SECONDS" -o /dev/null -w '%{http_code}' \
      "${KEYCLOAK_URL}/realms/${REALM}" 2>/dev/null || true)"
    if [ "$http_code" = "200" ]; then
      log "Keycloak is ready (HTTP 200)"
      return 0
    fi
    # No attempt count: retried until Keycloak answers; Kubernetes or a person stops the Job.
    log "Keycloak not ready yet (attempt ${attempt}, HTTP ${http_code}) — retrying in ${KEYCLOAK_READY_SLEEP_SECONDS}s"
    attempt=$((attempt + 1))
    sleep "${KEYCLOAK_READY_SLEEP_SECONDS}"
  done
}

# ---------------------------------------------------------------------------
# Realm import readiness
# ---------------------------------------------------------------------------

# wait_for_keycloak confirms only that the realm endpoint responds with HTTP 200.
# It does NOT confirm that the realm import has completed and all built-in clients
# (e.g. realm-management) are visible. This function waits for realm-management
# specifically, since Phase 3 depends on it to assign service account roles.
# Without this guard, the bootstrap Job races against the async realm import and
# Phase 3 fails silently or with a 403. Each attempt that is not an HTTP 200
# logs its status and Keycloak's response; the last one is the failure.
wait_for_realm_management_client() {
  log "Waiting for realm-management client to be visible in realm '${REALM}'..."
  url="${KEYCLOAK_URL}/admin/realms/${REALM}/clients?clientId=realm-management"
  attempt=1
  while :; do
    kc_request GET "$url"
    if [ "$KC_STATUS" = "200" ]; then
      uuid="$(jq -r '.[0].id // empty' "$KC_RESPONSE")"
      outcome="HTTP 200 without the client"
    else
      uuid=""
      outcome="HTTP ${KC_STATUS}: $(kc_redacted_body "$KC_RESPONSE")"
    fi
    rm -f "$KC_RESPONSE"
    if [ -n "$uuid" ]; then
      log "realm-management client is visible (uuid=${uuid})"
      return 0
    fi
    log "realm-management not yet visible (attempt ${attempt}, GET ${url} -> ${outcome}) — retrying in ${KEYCLOAK_READY_SLEEP_SECONDS}s"
    attempt=$((attempt + 1))
    sleep "${KEYCLOAK_READY_SLEEP_SECONDS}"
  done
}

# ---------------------------------------------------------------------------
# Realm roles
# ---------------------------------------------------------------------------

ensure_realm_role() {
  role_name="$1"
  description="$2"
  log "Checking realm role: ${role_name}"
  kc_call "200 404" GET "${KEYCLOAK_URL}/admin/realms/${REALM}/roles/${role_name}"
  rm -f "$KC_RESPONSE"
  if [ "$KC_STATUS" = "200" ]; then
    log "Realm role already exists: ${role_name}"
    return 0
  fi
  log "Creating realm role: ${role_name}"
  body="$(cat <<EOF
{
  "name": $(json_escape "$role_name"),
  "description": $(json_escape "$description")
}
EOF
)"
  kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/roles" "$body"
  log "Created realm role: ${role_name}"
}


get_realm_role_json() {
  role_name="$1"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/roles/${role_name}" \
    || fail "Could not fetch realm role '${role_name}'"
}

ensure_composite_role() {
  parent="$1"
  child="$2"
  log "Checking composite role: ${parent} -> ${child}"
  parent_json="$(get_realm_role_json "$parent")"
  parent_id="$(printf '%s' "$parent_json" | jq -r '.id')"
  [ -n "$parent_id" ] && [ "$parent_id" != "null" ] || fail "Missing id for role '${parent}'"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/roles-by-id/${parent_id}/composites" \
    | jq -r '.[].name' || true)"
  if printf '%s\n' "$existing" | grep -qx "$child"; then
    log "Composite already present: ${parent} -> ${child}"
    return 0
  fi
  log "Adding composite role: ${parent} -> ${child}"
  child_json="$(get_realm_role_json "$child")"
  kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/roles-by-id/${parent_id}/composites" "[$child_json]"
  log "Added composite role: ${parent} -> ${child}"
}

# ---------------------------------------------------------------------------
# Bootstrap user
# ---------------------------------------------------------------------------

get_user_id_by_username() {
  username="$1"
  encoded="$(printf '%s' "$username" | jq -sRr @uri)"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users?username=${encoded}" \
    | jq -r '.[0].id // empty'
}

create_or_update_bootstrap_user() {
  log "Looking up bootstrap user: ${ADMIN_USERNAME}"
  user_id="$(get_user_id_by_username "${ADMIN_USERNAME}" || true)"
  user_body="$(cat <<EOF
{
  "username":  $(json_escape "${ADMIN_USERNAME}"),
  "email":     $(json_escape "${ADMIN_EMAIL}"),
  "firstName": $(json_escape "${ADMIN_FIRST_NAME}"),
  "lastName":  $(json_escape "${ADMIN_LAST_NAME}"),
  "enabled": true,
  "emailVerified": true
}
EOF
)"
  user_body="$(printf '%s' "$user_body" | jq \
    --arg tenant_did "$ADMIN_TENANT_DID" \
    --arg actor_did "$ADMIN_ACTOR_DID" \
    --arg actor_type "$ADMIN_ACTOR_TYPE" \
    '.attributes = {
      "tenant_did": [$tenant_did],
      "actor_did": [$actor_did],
      "actor_type": [$actor_type]
    }')"
  if [ -z "$user_id" ]; then
    log "Bootstrap user not found — creating: ${ADMIN_USERNAME}"
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users" "$user_body"
    kc_await_user_id get_user_id_by_username "${ADMIN_USERNAME}"
    user_id="$KC_AWAITED_ID"
    log "Bootstrap user created: ${ADMIN_USERNAME} (id=${user_id})"
  else
    log "Bootstrap user found (id=${user_id}) — updating attributes"
    kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}" "$user_body"
    log "Bootstrap user updated: ${ADMIN_USERNAME} (id=${user_id})"
  fi
  BOOTSTRAP_USER_ID="$user_id"
  export BOOTSTRAP_USER_ID
}

set_bootstrap_user_password() {
  log "Setting password for user: ${BOOTSTRAP_USER_ID}"
  body="$(cat <<EOF
{
  "type": "password",
  "value": $(json_escape "${ADMIN_PASSWORD}"),
  "temporary": false
}
EOF
)"
  kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${BOOTSTRAP_USER_ID}/reset-password" "$body"
  log "Password set for user: ${BOOTSTRAP_USER_ID}"
}

assign_realm_role_to_user_if_missing() {
  user_id="$1"
  role_name="$2"
  log "Checking realm role '${role_name}' on user ${user_id}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/realm" \
    | jq -r '.[].name' || true)"
  if printf '%s\n' "$existing" | grep -qx "$role_name"; then
    log "User ${user_id} already has realm role: ${role_name}"
    return 0
  fi
  log "Assigning realm role '${role_name}' to user ${user_id}"
  role_json="$(get_realm_role_json "$role_name")"
  kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/realm" "[$role_json]"
  log "Assigned realm role '${role_name}' to user ${user_id}"
}

# ---------------------------------------------------------------------------
# Client / service-account helpers
# ---------------------------------------------------------------------------

get_client_uuid_by_client_id() {
  client_id="$1"
  encoded="$(printf '%s' "$client_id" | jq -sRr @uri)"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients?clientId=${encoded}" \
    | jq -r '.[0].id // empty'
}

get_service_account_user_id() {
  client_uuid="$1"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/service-account-user" \
    | jq -r '.id // empty'
}

assign_client_roles_to_user_if_missing() {
  user_id="$1"
  client_uuid="$2"
  roles_csv="$3"
  log "Checking client roles for user ${user_id} on client ${client_uuid}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/clients/${client_uuid}" \
    | jq -r '.[].name' || true)"
  payload="["
  first="true"
  OLD_IFS="$IFS"
  IFS=','
  for role in $roles_csv; do
    IFS="$OLD_IFS"
    trimmed="$(printf '%s' "$role" | tr -d '[:space:]')"
    [ -n "$trimmed" ] || continue
    if printf '%s\n' "$existing" | grep -qx "$trimmed"; then
      log "User ${user_id} already has client role: ${trimmed}"
    else
      log "Queuing client role for assignment: ${trimmed}"
      role_json="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/roles/${trimmed}" \
        || fail "Could not fetch client role '${trimmed}' from client ${client_uuid}")"
      if [ "$first" = "true" ]; then
        payload="${payload}${role_json}"
        first="false"
      else
        payload="${payload},${role_json}"
      fi
    fi
    IFS=','
  done
  IFS="$OLD_IFS"
  payload="${payload}]"
  if [ "$payload" != "[]" ]; then
    log "Assigning queued client roles to user ${user_id}"
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/clients/${client_uuid}" "$payload"
    log "Client roles assigned to user ${user_id}"
  else
    log "No new client roles to assign for user ${user_id}"
  fi
}

# ---------------------------------------------------------------------------
# Client scope helpers
# ---------------------------------------------------------------------------

get_scope_id_by_name() {
  scope_name="$1"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes" \
    | jq -r --arg n "$scope_name" '.[] | select(.name==$n) | .id' \
    | tr -d '\n'
}

ensure_client_scope() {
  scope_name="$1"
  scope_body="$2"
  log "Checking client scope: ${scope_name}"
  existing_id="$(get_scope_id_by_name "$scope_name" || true)"
  if [ -n "$existing_id" ]; then
    log "Client scope already exists: ${scope_name} (id=${existing_id})"
    printf '%s' "$existing_id"
    return 0
  fi
  log "Creating client scope: ${scope_name}"
  kc_call "201 409" POST "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes" "$scope_body"
  rm -f "$KC_RESPONSE"
  if [ "$KC_STATUS" = "409" ]; then
    log "Client scope '${scope_name}' already exists (409) — skipping creation"
  fi
  new_id="$(get_scope_id_by_name "$scope_name")"
  [ -n "$new_id" ] || fail "Created scope '${scope_name}' but could not retrieve its UUID"
  log "Created client scope: ${scope_name} (id=${new_id})"
  printf '%s' "$new_id"
}

ensure_scope_forwardmeasure_identity() {
  scope_body="$(cat <<'EOF'
{
  "name": "forwardmeasure_identity",
  "description": "Canonical tenant and actor identity claims for ForwardMeasure tokens",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "false"
  },
  "protocolMappers": [
    {
      "name": "tenant-did",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "user.attribute": "tenant_did",
        "claim.name": "tenant_did",
        "jsonType.label": "String",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "userinfo.token.claim": "true",
        "multivalued": "false",
        "aggregate.attrs": "false"
      }
    },
    {
      "name": "actor-did",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "user.attribute": "actor_did",
        "claim.name": "actor_did",
        "jsonType.label": "String",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "userinfo.token.claim": "true",
        "multivalued": "false",
        "aggregate.attrs": "false"
      }
    },
    {
      "name": "actor-type",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "user.attribute": "actor_type",
        "claim.name": "actor_type",
        "jsonType.label": "String",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "userinfo.token.claim": "true",
        "multivalued": "false",
        "aggregate.attrs": "false"
      }
    }
  ]
}
EOF
)"
  scope_id="$(ensure_client_scope "forwardmeasure_identity" "$scope_body")"
  kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}" "$scope_body"
  log "Canonical identity client scope reconciled (id=${scope_id})"
  printf '%s' "$scope_id"
}

assign_default_scope_to_client_if_missing() {
  client_uuid="$1"
  scope_name="$2"
  scope_id="$3"
  log "Checking default scope '${scope_name}' on client ${client_uuid}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/default-client-scopes" \
    | jq -r '.[].name' || true)"
  if printf '%s\n' "$existing" | grep -qx "$scope_name"; then
    log "Default scope '${scope_name}' already assigned to client ${client_uuid}"
    return 0
  fi
  log "Assigning default scope '${scope_name}' to client ${client_uuid}"
  kc_put_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/default-client-scopes/${scope_id}"
  log "Assigned default scope '${scope_name}' to client ${client_uuid}"
}

assign_optional_scope_to_client_if_missing() {
  client_uuid="$1"
  scope_name="$2"
  scope_id="$3"
  log "Checking optional scope '${scope_name}' on client ${client_uuid}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/optional-client-scopes" \
    | jq -r '.[].name' || true)"
  if printf '%s\n' "$existing" | grep -qx "$scope_name"; then
    log "Optional scope '${scope_name}' already assigned to client ${client_uuid}"
    return 0
  fi
  log "Assigning optional scope '${scope_name}' to client ${client_uuid}"
  kc_put_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/optional-client-scopes/${scope_id}"
  log "Assigned optional scope '${scope_name}' to client ${client_uuid}"
}

# ---------------------------------------------------------------------------
# Built-in scope definitions
# ---------------------------------------------------------------------------

ensure_scope_roles() {
  ensure_client_scope "roles" "$(cat <<'EOF'
{
  "name": "roles",
  "description": "OpenID Connect scope for add user roles to the access token",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "false",
    "display.on.consent.screen": "true",
    "consent.screen.text": "${rolesScopeConsentText}"
  },
  "protocolMappers": [
    {
      "name": "realm roles",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-realm-role-mapper",
      "consentRequired": false,
      "config": {
        "multivalued": "true",
        "user.attribute": "foo",
        "access.token.claim": "true",
        "claim.name": "realm_access.roles",
        "jsonType.label": "String"
      }
    },
    {
      "name": "client roles",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-client-role-mapper",
      "consentRequired": false,
      "config": {
        "multivalued": "true",
        "user.attribute": "foo",
        "access.token.claim": "true",
        "claim.name": "resource_access.${client_id}.roles",
        "jsonType.label": "String"
      }
    },
    {
      "name": "audience resolve",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-audience-resolve-mapper",
      "consentRequired": false,
      "config": {}
    }
  ]
}
EOF
)"
}

ensure_scope_profile() {
  ensure_client_scope "profile" "$(cat <<'EOF'
{
  "name": "profile",
  "description": "OpenID Connect built-in scope: profile",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true",
    "consent.screen.text": "${profileScopeConsentText}"
  },
  "protocolMappers": [
    {
      "name": "username",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-property-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "username",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "preferred_username",
        "jsonType.label": "String"
      }
    },
    {
      "name": "full name",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-full-name-mapper",
      "consentRequired": false,
      "config": {
        "id.token.claim": "true",
        "access.token.claim": "true",
        "userinfo.token.claim": "true"
      }
    },
    {
      "name": "family name",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-property-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "lastName",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "family_name",
        "jsonType.label": "String"
      }
    },
    {
      "name": "given name",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-property-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "firstName",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "given_name",
        "jsonType.label": "String"
      }
    },
    {
      "name": "updated at",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "updatedAt",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "updated_at",
        "jsonType.label": "long"
      }
    }
  ]
}
EOF
)"
}

ensure_scope_email() {
  ensure_client_scope "email" "$(cat <<'EOF'
{
  "name": "email",
  "description": "OpenID Connect built-in scope: email",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true",
    "consent.screen.text": "${emailScopeConsentText}"
  },
  "protocolMappers": [
    {
      "name": "email",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-property-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "email",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "email",
        "jsonType.label": "String"
      }
    },
    {
      "name": "email verified",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-property-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "emailVerified",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "email_verified",
        "jsonType.label": "boolean"
      }
    }
  ]
}
EOF
)"
}

ensure_scope_web_origins() {
  ensure_client_scope "web-origins" "$(cat <<'EOF'
{
  "name": "web-origins",
  "description": "OpenID Connect scope for web origins",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "false",
    "display.on.consent.screen": "false",
    "consent.screen.text": ""
  },
  "protocolMappers": [
    {
      "name": "allowed web origins",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-allowed-origins-mapper",
      "consentRequired": false,
      "config": {}
    }
  ]
}
EOF
)"
}

ensure_scope_acr() {
  ensure_client_scope "acr" "$(cat <<'EOF'
{
  "name": "acr",
  "description": "OpenID Connect scope for add acr (authentication context class reference) to the token",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "false",
    "display.on.consent.screen": "false"
  },
  "protocolMappers": [
    {
      "name": "acr loa level",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-acr-mapper",
      "consentRequired": false,
      "config": {
        "id.token.claim": "true",
        "access.token.claim": "true",
        "userinfo.token.claim": "true"
      }
    }
  ]
}
EOF
)"
}

ensure_scope_openid() {
  ensure_client_scope "openid" "$(cat <<'EOF'
{
  "name": "openid",
  "description": "OpenID Connect built-in scope: openid",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "false"
  },
  "protocolMappers": [
    {
      "name": "sub",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-sub-mapper",
      "consentRequired": false,
      "config": {
        "access.token.claim": "true",
        "id.token.claim": "true"
      }
    }
  ]
}
EOF
)"
}

ensure_scope_address() {
  ensure_client_scope "address" "$(cat <<'EOF'
{
  "name": "address",
  "description": "OpenID Connect built-in scope: address",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true",
    "consent.screen.text": "${addressScopeConsentText}"
  },
  "protocolMappers": [
    {
      "name": "address",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-address-mapper",
      "consentRequired": false,
      "config": {
        "user.attribute.formatted": "formatted",
        "user.attribute.country": "country",
        "user.attribute.postal_code": "postal_code",
        "userinfo.token.claim": "true",
        "user.attribute.street": "street",
        "id.token.claim": "true",
        "user.attribute.region": "region",
        "access.token.claim": "true",
        "user.attribute.locality": "locality"
      }
    }
  ]
}
EOF
)"
}

ensure_scope_phone() {
  ensure_client_scope "phone" "$(cat <<'EOF'
{
  "name": "phone",
  "description": "OpenID Connect built-in scope: phone",
  "protocol": "openid-connect",
  "attributes": {
    "include.in.token.scope": "true",
    "display.on.consent.screen": "true",
    "consent.screen.text": "${phoneScopeConsentText}"
  },
  "protocolMappers": [
    {
      "name": "phone number",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "phoneNumber",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "phone_number",
        "jsonType.label": "String"
      }
    },
    {
      "name": "phone number verified",
      "protocol": "openid-connect",
      "protocolMapper": "oidc-usermodel-attribute-mapper",
      "consentRequired": false,
      "config": {
        "userinfo.token.claim": "true",
        "user.attribute": "phoneNumberVerified",
        "id.token.claim": "true",
        "access.token.claim": "true",
        "claim.name": "phone_number_verified",
        "jsonType.label": "boolean"
      }
    }
  ]
}
EOF
)"
}

# ---------------------------------------------------------------------------
# Phase 4 orchestration: ensure built-in scopes + assign to clients
# ---------------------------------------------------------------------------

configure_client_scopes() {
  log_section "Phase 4: built-in client scopes"

  log "Ensuring built-in client scopes exist..."
  SCOPE_ID_ROLES="$(ensure_scope_roles)"
  SCOPE_ID_PROFILE="$(ensure_scope_profile)"
  SCOPE_ID_EMAIL="$(ensure_scope_email)"
  SCOPE_ID_WEB_ORIGINS="$(ensure_scope_web_origins)"
  SCOPE_ID_ACR="$(ensure_scope_acr)"
  SCOPE_ID_OPENID="$(ensure_scope_openid)"
  SCOPE_ID_ADDRESS="$(ensure_scope_address)"
  SCOPE_ID_PHONE="$(ensure_scope_phone)"
  SCOPE_ID_OFFLINE="$(get_scope_id_by_name "offline_access")"
  SCOPE_ID_IDENTITY="$(ensure_scope_forwardmeasure_identity)"

  [ -n "$SCOPE_ID_OFFLINE" ] || fail "Could not find scope 'offline_access' — realm import may have failed"
  [ -n "$SCOPE_ID_IDENTITY" ] || fail "Could not reconcile scope 'forwardmeasure_identity'"

  log "All client scopes verified"

  # ForwardMeasure public client
  log "Configuring scopes for client: ${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}"
  admin_pub_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}")"
  [ -n "$admin_pub_uuid" ] || fail "Could not resolve UUID for client '${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}'"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "web-origins"   "$SCOPE_ID_WEB_ORIGINS"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "acr"            "$SCOPE_ID_ACR"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "openid"         "$SCOPE_ID_OPENID"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "roles"          "$SCOPE_ID_ROLES"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "profile"        "$SCOPE_ID_PROFILE"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "email"          "$SCOPE_ID_EMAIL"
  assign_optional_scope_to_client_if_missing "$admin_pub_uuid" "address"        "$SCOPE_ID_ADDRESS"
  assign_optional_scope_to_client_if_missing "$admin_pub_uuid" "phone"          "$SCOPE_ID_PHONE"
  assign_optional_scope_to_client_if_missing "$admin_pub_uuid" "offline_access" "$SCOPE_ID_OFFLINE"
  assign_default_scope_to_client_if_missing  "$admin_pub_uuid" "forwardmeasure_identity" "$SCOPE_ID_IDENTITY"

  # ForwardMeasure confidential client
  log "Configuring scopes for client: ${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}"
  admin_conf_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}")"
  [ -n "$admin_conf_uuid" ] || fail "Could not resolve UUID for client '${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}'"
  assign_default_scope_to_client_if_missing  "$admin_conf_uuid" "acr"            "$SCOPE_ID_ACR"
  assign_default_scope_to_client_if_missing  "$admin_conf_uuid" "openid"         "$SCOPE_ID_OPENID"
  assign_default_scope_to_client_if_missing  "$admin_conf_uuid" "roles"          "$SCOPE_ID_ROLES"
  assign_optional_scope_to_client_if_missing "$admin_conf_uuid" "offline_access" "$SCOPE_ID_OFFLINE"

  log "Client scopes configured"
}

# ---------------------------------------------------------------------------
# Reconcile the public browser client's deployment-specific redirect settings.
# Realm import in bootstrap mode creates these values only on first install;
# this reconciliation keeps an existing client current on Helm upgrades.
# ---------------------------------------------------------------------------

configure_public_client_redirects() {
  log_section "Public client redirect configuration"

  client_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}")"
  [ -n "$client_uuid" ] || fail "Could not resolve UUID for client '${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}'"

  client_json="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}")"
  updated_json="$(
    printf '%s' "$client_json" | jq \
      --arg redirect1 "${FORWARDMEASURE_ADMIN_PUBLIC_REDIRECT_URI_1}" \
      --arg redirect2 "${FORWARDMEASURE_ADMIN_PUBLIC_REDIRECT_URI_2}" \
      --argjson additionalRedirects "${FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_REDIRECT_URIS_JSON}" \
      --arg origin1 "${FORWARDMEASURE_ADMIN_PUBLIC_WEB_ORIGIN_1}" \
      --arg origin2 "${FORWARDMEASURE_ADMIN_PUBLIC_WEB_ORIGIN_2}" \
      --argjson additionalOrigins "${FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_WEB_ORIGINS_JSON}" \
      --arg logout "${FORWARDMEASURE_ADMIN_PUBLIC_POST_LOGOUT_REDIRECT_URIS}" \
      '.redirectUris = ([$redirect1, $redirect2] + $additionalRedirects | map(select(type == "string" and length > 0)) | unique)
       | .webOrigins = ([$origin1, $origin2] + $additionalOrigins | map(select(type == "string" and length > 0)) | unique)
       | .attributes["post.logout.redirect.uris"] = $logout'
  )"

  kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}" "$updated_json"
  log "Redirect URIs and web origins reconciled for client: ${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}"
}

configure_public_client_audiences() {
  log_section "Public client audience configuration"
  client_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}")"
  [ -n "$client_uuid" ] || fail "Could not resolve UUID for client '${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}'"
  reconcile_client_audiences "$client_uuid" "${FORWARDMEASURE_ADMIN_PUBLIC_AUDIENCES_JSON}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models")"
  printf '%s' "${FORWARDMEASURE_ADMIN_PUBLIC_AUDIENCES_JSON}" | jq -r '.[]' | while IFS= read -r audience; do
    mapper_name="hardcoded-audience:${audience}"
    if printf '%s' "$existing" | jq -e --arg name "$mapper_name" '.[] | select(.name == $name)' >/dev/null; then
      log "Audience mapper already exists: ${audience}"
      continue
    fi
    body="$(jq -n --arg name "$mapper_name" --arg audience "$audience" '{
      name: $name,
      protocol: "openid-connect",
      protocolMapper: "oidc-audience-mapper",
      consentRequired: false,
      config: {
        "included.custom.audience": $audience,
        "access.token.claim": "true",
        "id.token.claim": "false"
      }
    }')"
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models" "$body"
    log "Created public-client audience mapper: ${audience}"
  done
}

ensure_client_audience() {
  client_uuid="$1"
  audience="$2"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models")"
  mapper_name="hardcoded-audience:${audience}"
  if printf '%s' "$existing" | jq -e --arg name "$mapper_name" '.[] | select(.name == $name)' >/dev/null; then
    return 0
  fi
  body="$(jq -n --arg name "$mapper_name" --arg audience "$audience" '{
    name: $name,
    protocol: "openid-connect",
    protocolMapper: "oidc-audience-mapper",
    consentRequired: false,
    config: {
      "included.custom.audience": $audience,
      "access.token.claim": "true",
      "id.token.claim": "false"
    }
  }')"
  kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models" "$body"
}

reconcile_client_audiences() {
  client_uuid="$1"
  desired="$2"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models")"
  printf '%s' "$existing" | jq -c '.[] | select(.name | startswith("hardcoded-audience:"))' \
    | while IFS= read -r mapper; do
      mapper_id="$(printf '%s' "$mapper" | jq -r '.id')"
      audience="$(printf '%s' "$mapper" | jq -r '.config["included.custom.audience"] // empty')"
      if ! printf '%s' "$desired" | jq -e --arg audience "$audience" \
          'index($audience) != null' >/dev/null; then
        kc_delete_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models/${mapper_id}"
        log "Removed obsolete service-client audience mapper: ${audience}"
      fi
    done
}

ensure_client_hardcoded_claim() {
  client_uuid="$1"
  claim_name="$2"
  claim_value="$3"
  mapper_name="hardcoded-claim:${claim_name}"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models")"
  existing_mapper="$(printf '%s' "$existing" | jq -c --arg name "$mapper_name" '.[] | select(.name == $name)' | head -n 1)"
  body="$(jq -n \
    --arg name "$mapper_name" \
    --arg claim "$claim_name" \
    --arg value "$claim_value" '{
      name: $name,
      protocol: "openid-connect",
      protocolMapper: "oidc-hardcoded-claim-mapper",
      consentRequired: false,
      config: {
        "claim.name": $claim,
        "claim.value": $value,
        "jsonType.label": "String",
        "access.token.claim": "true",
        "id.token.claim": "false",
        "userinfo.token.claim": "false"
      }
    }')"
  if [ -z "$existing_mapper" ]; then
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models" "$body"
    return 0
  fi
  mapper_id="$(printf '%s' "$existing_mapper" | jq -r '.id')"
  if ! printf '%s' "$existing_mapper" | jq -e \
      --arg claim "$claim_name" --arg value "$claim_value" '
        .protocol == "openid-connect"
        and .protocolMapper == "oidc-hardcoded-claim-mapper"
        and .config["claim.name"] == $claim
        and .config["claim.value"] == $value
        and .config["jsonType.label"] == "String"
        and .config["access.token.claim"] == "true"
        and .config["id.token.claim"] == "false"
        and .config["userinfo.token.claim"] == "false"' >/dev/null; then
    body="$(printf '%s' "$body" | jq --arg id "$mapper_id" '.id = $id')"
    kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models/${mapper_id}" "$body"
  fi
  printf '%s' "$existing" | jq -r --arg name "$mapper_name" \
    '[.[] | select(.name == $name) | .id][1:][]' \
    | while IFS= read -r duplicate_id; do
      kc_delete_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models/${duplicate_id}"
      log "Removed duplicate service-client hardcoded claim mapper: ${claim_name}"
    done
}

reconcile_client_hardcoded_claims() {
  client_uuid="$1"
  desired="$2"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models")"
  printf '%s' "$existing" | jq -c '.[] | select(.name | startswith("hardcoded-claim:"))' \
    | while IFS= read -r mapper; do
      mapper_id="$(printf '%s' "$mapper" | jq -r '.id')"
      claim_name="$(printf '%s' "$mapper" | jq -r '.config["claim.name"] // empty')"
      if ! printf '%s' "$desired" | jq -e --arg claim "$claim_name" \
          'has($claim)' >/dev/null; then
        kc_delete_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/protocol-mappers/models/${mapper_id}"
        log "Removed obsolete service-client hardcoded claim: ${claim_name}"
      fi
    done
}

reconcile_service_account_realm_roles() {
  user_id="$1"
  desired="$2"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/realm")"
  printf '%s' "$existing" | jq -c '.[]' | while IFS= read -r role_json; do
    role_name="$(printf '%s' "$role_json" | jq -r '.name')"
    if ! printf '%s' "$desired" | jq -e --arg role "$role_name" \
        'index($role) != null' >/dev/null; then
      kc_delete_json \
        "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/realm" \
        "[$role_json]"
      log "Removed obsolete service-account realm role: ${role_name}"
    fi
  done
}

reconcile_service_account_realm_management_roles() {
  # Exactly the declared realm-management client roles - a read-only Admin REST identity
  # (e.g. view-users, view-organizations) gains nothing else and keeps nothing it no longer declares.
  user_id="$1"
  desired="$2"
  realm_mgmt_uuid="$(get_client_uuid_by_client_id "realm-management")"
  [ -n "$realm_mgmt_uuid" ] || fail "Could not resolve realm-management client uuid"
  existing="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/clients/${realm_mgmt_uuid}")"
  printf '%s' "$existing" | jq -c '.[]' | while IFS= read -r role_json; do
    role_name="$(printf '%s' "$role_json" | jq -r '.name')"
    if ! printf '%s' "$desired" | jq -e --arg role "$role_name" \
        'index($role) != null' >/dev/null; then
      kc_delete_json \
        "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}/role-mappings/clients/${realm_mgmt_uuid}" \
        "[$role_json]"
      log "Removed obsolete service-account realm-management role: ${role_name}"
    fi
  done
  desired_csv="$(printf '%s' "$desired" | jq -r 'join(",")')"
  if [ -n "$desired_csv" ]; then
    assign_client_roles_to_user_if_missing "$user_id" "$realm_mgmt_uuid" "$desired_csv"
  fi
}

configure_service_clients() {
  log_section "Least-privilege service clients"
  printf '%s' "${FORWARDMEASURE_SERVICE_CLIENTS_JSON}" | jq -e 'type == "array"' >/dev/null \
    || fail "FORWARDMEASURE_SERVICE_CLIENTS_JSON must be a JSON array"
  count="$(printf '%s' "${FORWARDMEASURE_SERVICE_CLIENTS_JSON}" | jq 'length')"
  index=0
  while [ "$index" -lt "$count" ]; do
    client="$(printf '%s' "${FORWARDMEASURE_SERVICE_CLIENTS_JSON}" | jq -c ".[$index]")"
    client_id="$(printf '%s' "$client" | jq -er '.clientId | select(type == "string" and length > 0)')" \
      || fail "serviceClients[$index].clientId is required"
    client_name="$(printf '%s' "$client" | jq -er '.name | select(type == "string" and length > 0)')" \
      || fail "serviceClients[$index].name is required"
    secret_key="$(printf '%s' "$client" | jq -er '.secretKey | select(type == "string" and test("^[A-Za-z0-9_.-]+$"))')" \
      || fail "serviceClients[$index].secretKey is invalid"
    secret_path="${FORWARDMEASURE_SERVICE_CLIENT_SECRETS_DIRECTORY}/${secret_key}"
    [ -f "$secret_path" ] || fail "Missing secret key '${secret_key}' for service client '${client_id}'"
    client_secret="$(cat "$secret_path")"
    [ -n "$client_secret" ] || fail "Secret key '${secret_key}' is empty"
    # Off by default (least-privilege: most service clients never touch Keycloak's authz
    # admin API at all) - a client opts in when it owns resources/scopes/policies/permissions
    # of its own (e.g. openworkflow's TenantOrganizationReconciler). Without this, Keycloak's
    # /authz/resource-server/* endpoints 404 for the client - there is no resource server to
    # query - which is indistinguishable from a real 404 to the caller.
    # A valid false is data, not an error: jq -e would reject clients without authz.
    authz_enabled="$(printf '%s' "$client" | jq -r '(.authorizationServicesEnabled // false) | if type == "boolean" then . else error("must be a boolean") end')" \
      || fail "serviceClients[$index].authorizationServicesEnabled is invalid"
    body="$(jq -n --arg id "$client_id" --arg name "$client_name" --arg secret "$client_secret" --argjson authzEnabled "$authz_enabled" '{
      clientId: $id,
      name: $name,
      description: "Least-privilege ForwardMeasure workload client",
      enabled: true,
      protocol: "openid-connect",
      publicClient: false,
      bearerOnly: false,
      standardFlowEnabled: false,
      implicitFlowEnabled: false,
      directAccessGrantsEnabled: false,
      serviceAccountsEnabled: true,
      authorizationServicesEnabled: $authzEnabled,
      clientAuthenticatorType: "client-secret",
      secret: $secret
    }')"
    client_uuid="$(get_client_uuid_by_client_id "$client_id")"
    if [ -z "$client_uuid" ]; then
      kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients" "$body"
      client_uuid="$(get_client_uuid_by_client_id "$client_id")"
    else
      existing_client="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}")"
      updated_client="$(printf '%s' "$existing_client" | jq --arg name "$client_name" --arg secret "$client_secret" --argjson authzEnabled "$authz_enabled" '
        .name = $name
        | .enabled = true
        | .publicClient = false
        | .bearerOnly = false
        | .standardFlowEnabled = false
        | .implicitFlowEnabled = false
        | .directAccessGrantsEnabled = false
        | .serviceAccountsEnabled = true
        | .authorizationServicesEnabled = $authzEnabled
        | .clientAuthenticatorType = "client-secret"
        | .secret = $secret')"
      kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}" "$updated_client"
    fi
    [ -n "$client_uuid" ] || fail "Could not reconcile service client '${client_id}'"
    assign_default_scope_to_client_if_missing "$client_uuid" "openid" "$SCOPE_ID_OPENID"
    assign_default_scope_to_client_if_missing "$client_uuid" "roles" "$SCOPE_ID_ROLES"
    service_user="$(get_service_account_user_id "$client_uuid")"
    [ -n "$service_user" ] || fail "No service account exists for '${client_id}'"
    role_count="$(printf '%s' "$client" | jq -er '(.realmRoles // []) | if type == "array" then length else error("realmRoles must be an array") end')" \
      || fail "serviceClients[$index].realmRoles must be an array"
    desired_roles="$(printf '%s' "$client" | jq -c '.realmRoles // []')"
    reconcile_service_account_realm_roles "$service_user" "$desired_roles"
    role_index=0
    while [ "$role_index" -lt "$role_count" ]; do
      role="$(printf '%s' "$client" | jq -er ".realmRoles[$role_index] | select(type == \"string\" and length > 0)")" \
        || fail "serviceClients[$index].realmRoles[$role_index] is invalid"
      ensure_realm_role "$role" "ForwardMeasure workload authorization role"
      assign_realm_role_to_user_if_missing "$service_user" "$role"
      role_index=$((role_index + 1))
    done
    # Optional: realm-management client roles for a service that reads (or administers) the realm
    # through Admin REST as itself. Absent leaves the account's realm-management roles untouched;
    # present (even empty) reconciles them to exactly the listed ones.
    if printf '%s' "$client" | jq -e 'has("realmManagementRoles")' >/dev/null; then
      realm_management_roles="$(printf '%s' "$client" | jq -ec '.realmManagementRoles
        | if type == "array" and all(.[]; type == "string" and test("^[a-z][a-z-]*$"))
          then . else error("realmManagementRoles must be an array of role names") end')" \
        || fail "serviceClients[$index].realmManagementRoles is invalid"
      reconcile_service_account_realm_management_roles "$service_user" "$realm_management_roles"
    fi
    audience_count="$(printf '%s' "$client" | jq -er '(.audiences // []) | if type == "array" then length else error("audiences must be an array") end')" \
      || fail "serviceClients[$index].audiences must be an array"
    desired_audiences="$(printf '%s' "$client" | jq -c '.audiences // []')"
    reconcile_client_audiences "$client_uuid" "$desired_audiences"
    audience_index=0
    while [ "$audience_index" -lt "$audience_count" ]; do
      audience="$(printf '%s' "$client" | jq -er ".audiences[$audience_index] | select(type == \"string\" and length > 0)")" \
        || fail "serviceClients[$index].audiences[$audience_index] is invalid"
      ensure_client_audience "$client_uuid" "$audience"
      audience_index=$((audience_index + 1))
    done
    claims="$(printf '%s' "$client" | jq -ec '
      (.claims // {})
      | if type == "object"
        then with_entries(
          if ((.key | test("^[A-Za-z][A-Za-z0-9_.-]*$"))
            and ((.key | test("^(iss|sub|aud|exp|iat|nbf|jti|azp)$")) | not)
            and (.value | type == "string" and length > 0))
          then .
          else error("claims must contain non-empty string values under safe, non-reserved claim names")
          end)
        else error("claims must be an object")
        end')" \
      || fail "serviceClients[$index].claims is invalid"
    reconcile_client_hardcoded_claims "$client_uuid" "$claims"
    printf '%s' "$claims" | jq -c 'to_entries[]' | while IFS= read -r claim; do
      claim_name="$(printf '%s' "$claim" | jq -r '.key')"
      claim_value="$(printf '%s' "$claim" | jq -r '.value')"
      ensure_client_hardcoded_claim "$client_uuid" "$claim_name" "$claim_value"
    done
    # Membership belongs to tenant provisioning. This hook only enables the claim mapper.
    organization_claim="$(printf '%s' "$client" | jq -r '(.organizationClaim // false) | if type == "boolean" then . else error("must be a boolean") end')" \
      || fail "serviceClients[$index].organizationClaim is invalid"
    organization_scope="$(get_scope_id_by_name organization)"
    [ -n "$organization_scope" ] || fail "Organization client scope is missing"
    if [ "$organization_claim" = true ]; then
      assign_default_scope_to_client_if_missing "$client_uuid" "organization" "$organization_scope"
    else
      default_scopes="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/default-client-scopes")"
      if printf '%s' "$default_scopes" | jq -e --arg id "$organization_scope" 'any(.[]; .id == $id)' >/dev/null; then
        kc_delete_no_body "${KEYCLOAK_URL}/admin/realms/${REALM}/clients/${client_uuid}/default-client-scopes/${organization_scope}"
      fi
    fi
    log "Service client reconciled: ${client_id}"
    unset client_secret
    index=$((index + 1))
  done
}

# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

configure_platform_roles() {
  log_section "Phase 1: platform realm roles"
  ensure_realm_role "${FORWARDMEASURE_ROLE_VIEWER}"         "Read-only access to ForwardMeasure platform"
  ensure_realm_role "${FORWARDMEASURE_ROLE_ACCESS_ADMIN}"   "Manage users, roles, and access in ForwardMeasure"
  ensure_realm_role "${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}" "Full administrative access to ForwardMeasure platform"
  ensure_composite_role "${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}" "${FORWARDMEASURE_ROLE_VIEWER}"
  ensure_composite_role "${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}" "${FORWARDMEASURE_ROLE_ACCESS_ADMIN}"
  log "Platform roles configured"
}

configure_services_roles() {
  log_section "Phase 1a: services realm roles"
  if [ -z "${FORWARDMEASURE_TENANT_GROUP_ROLES}" ]; then
    log "FORWARDMEASURE_TENANT_GROUP_ROLES is empty — skipping services roles"
    return 0
  fi
  OLD_IFS="$IFS"
  IFS=','
  for role in ${FORWARDMEASURE_TENANT_GROUP_ROLES}; do
    IFS="$OLD_IFS"
    trimmed="$(printf '%s' "$role" | tr -d '[:space:]')"
    [ -n "$trimmed" ] || continue
    ensure_realm_role "$trimmed" "ForwardMeasure tenant service role: ${trimmed}"
    IFS=','
  done
  IFS="$OLD_IFS"
  log "Services roles configured"
}

configure_bootstrap_user() {
  log_section "Phase 2: bootstrap admin user"
  create_or_update_bootstrap_user
  set_bootstrap_user_password
  assign_realm_role_to_user_if_missing "${BOOTSTRAP_USER_ID}" "${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}"
  log "Bootstrap user configured"
}

# ---------------------------------------------------------------------------
# Tenant administrators
# ---------------------------------------------------------------------------

# Each one administers one tenant only. Created once, with the temporary
# password from its passwordKey file (Keycloak makes them change it at first
# login); a later run updates the profile and identity attributes but never
# resets the password they chose. No platform realm role: their tenant roles
# are their tenant Organization's role groups, which OpenWorkflow's tenant
# reconciliation (the capability packs' members) adds them to.
configure_tenant_administrators() {
  log_section "Phase 2a: tenant administrators"
  administrators="${FORWARDMEASURE_TENANT_ADMINISTRATORS_JSON:-[]}"
  count="$(printf '%s' "$administrators" | jq 'length')"
  if [ "$count" -eq 0 ]; then
    log "No tenant administrators configured"
    return 0
  fi
  index=0
  while [ "$index" -lt "$count" ]; do
    configure_tenant_administrator "$(printf '%s' "$administrators" | jq -c ".[$index]")"
    index=$((index + 1))
  done
  log "Tenant administrators configured: ${count}"
}

get_user_id_by_exact_username() {
  encoded="$(printf '%s' "$1" | jq -sRr @uri)"
  kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/users?username=${encoded}&exact=true" \
    | jq -r '.[0].id // empty'
}

# A tenant administrator may be declared a platform viewer (platformRoles: [platform-viewer]), to read
# platform service health - never any other platform role: tenant administration grants no control
# over the platform. Refused before anything is written.
require_tenant_administrator_platform_roles() {
  for role in $(printf '%s' "$1" | jq -r '.platformRoles // [] | .[]'); do
    [ "$role" = "platform-viewer" ] \
      || fail "Tenant administrator $(printf '%s' "$1" | jq -r '.username') may be declared only platform-viewer, not ${role}"
  done
}

assign_tenant_administrator_platform_roles() {
  for role in $(printf '%s' "$2" | jq -r '.platformRoles // [] | .[]'); do
    assign_realm_role_to_user_if_missing "$1" "$role"
  done
}

configure_tenant_administrator() {
  administrator="$1"
  require_tenant_administrator_platform_roles "$administrator"
  username="$(printf '%s' "$administrator" | jq -r '.username')"
  password_key="$(printf '%s' "$administrator" | jq -r '.passwordKey')"
  user_body="$(printf '%s' "$administrator" | jq '{
      username, email, firstName, lastName,
      enabled: true,
      emailVerified: true,
      attributes: {
        tenant_did: [.tenantDid],
        actor_did: [.actorDid],
        actor_type: [.actorType]
      }
    }')"
  user_id="$(get_user_id_by_exact_username "$username" || true)"
  if [ -n "$user_id" ]; then
    log "Tenant administrator found (id=${user_id}) — updating profile, keeping password: ${username}"
    kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users/${user_id}" "$user_body"
    assign_tenant_administrator_platform_roles "$user_id" "$administrator"
    return 0
  fi
  password_file="${FORWARDMEASURE_TENANT_ADMINISTRATOR_PASSWORDS_DIRECTORY}/${password_key}"
  [ -s "$password_file" ] || fail "Tenant administrator ${username}: no initial password at ${password_file}"
  log "Tenant administrator not found — creating with a temporary password: ${username}"
  user_body="$(printf '%s' "$user_body" | jq --arg password "$(cat "$password_file")" \
    '. + {credentials: [{type: "password", value: $password, temporary: true}]}')"
  kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/users" "$user_body"
  kc_await_user_id get_user_id_by_exact_username "$username"
  user_id="$KC_AWAITED_ID"
  log "Tenant administrator created: ${username} (id=${user_id})"
  assign_tenant_administrator_platform_roles "$user_id" "$administrator"
}

# Keycloak auto-creates the "organization" client scope once
# organizationsEnabled=true on the realm, but the scope isn't attached to
# any client by default, and KeycloakOrganizationClaims.extract() (the
# fail-closed authorization-context reader every OpenWorkflow API call goes
# through) needs it on the token. Confirmed live: without this, a real
# user's token has no "organization" claim at all and every authorization
# check 500s with "organization claim is required".
#
# oidc-organization-group-membership-mapper (with addGroupRoleMappings) is
# what nests a user's org-scoped client roles into this same claim as
# KeycloakOrganizationClaims' "resource_access.{clientId}.roles" - it
# requires Keycloak 26.7+ (confirmed against 26.5: POST-ing it 404s
# "ProtocolMapper provider not found"; confirmed against 26.7.2: it's a
# registered provider, per /admin/serverinfo's protocol-mapper list).
configure_organization_claim() {
  log_section "Phase 3a: organization claim"
  scope_id="$(get_scope_id_by_name organization)"
  if [ -z "$scope_id" ]; then
    scope_id="$(ensure_client_scope "organization" '{"name":"organization","protocol":"openid-connect","attributes":{"include.in.token.scope":"true","display.on.consent.screen":"false"}}')"
  fi
  existing_mappers="$(kc_get "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}/protocol-mappers/models")"
  membership_mapper_id="$(printf '%s' "$existing_mappers" | jq -r '.[] | select(.protocolMapper=="oidc-organization-membership-mapper") | .id' | head -n1)"
  membership_body="$(jq -n --arg id "$membership_mapper_id" '{
    name: "organization", protocol: "openid-connect",
    protocolMapper: "oidc-organization-membership-mapper", consentRequired: false,
    config: {
      "id.token.claim": "true", "introspection.token.claim": "true", "access.token.claim": "true",
      "claim.name": "organization", "jsonType.label": "JSON", "multivalued": "true",
      "addOrganizationAttributes": "true", "addOrganizationId": "true"
    }
  } + (if $id != "" then {id: $id} else {} end)')"
  if [ -n "$membership_mapper_id" ]; then
    kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}/protocol-mappers/models/${membership_mapper_id}" "$membership_body"
    log "Reconciled existing oidc-organization-membership-mapper (id=${membership_mapper_id})"
  else
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}/protocol-mappers/models" "$membership_body"
    log "Created oidc-organization-membership-mapper"
  fi
  group_mapper_id="$(printf '%s' "$existing_mappers" | jq -r '.[] | select(.protocolMapper=="oidc-organization-group-membership-mapper") | .id' | head -n1)"
  group_body="$(jq -n --arg id "$group_mapper_id" '{
    name: "organization-group-membership", protocol: "openid-connect",
    protocolMapper: "oidc-organization-group-membership-mapper", consentRequired: false,
    config: {
      "id.token.claim": "true", "introspection.token.claim": "true", "access.token.claim": "true",
      "claim.name": "organization", "addGroupRoleMappings": "true"
    }
  } + (if $id != "" then {id: $id} else {} end)')"
  if [ -n "$group_mapper_id" ]; then
    kc_put_json "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}/protocol-mappers/models/${group_mapper_id}" "$group_body"
    log "Reconciled existing oidc-organization-group-membership-mapper (id=${group_mapper_id})"
  else
    kc_post_json "${KEYCLOAK_URL}/admin/realms/${REALM}/client-scopes/${scope_id}/protocol-mappers/models" "$group_body"
    log "Created oidc-organization-group-membership-mapper"
  fi
  admin_pub_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}")"
  [ -n "$admin_pub_uuid" ] || fail "Could not resolve UUID for client '${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}'"
  assign_default_scope_to_client_if_missing "$admin_pub_uuid" "organization" "$scope_id"
  log "Organization claim configured for client: ${FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID}"
}

configure_admin_confidential_service_account() {
  log_section "Phase 3: admin confidential client service account"
  log "Resolving client uuid for: ${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}"
  admin_client_uuid="$(get_client_uuid_by_client_id "${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}")"
  [ -n "$admin_client_uuid" ] || fail "Could not resolve client uuid for '${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}'"
  log "Resolved client uuid: ${admin_client_uuid}"
  log "Resolving service account user for client: ${admin_client_uuid}"
  service_account_user_id="$(get_service_account_user_id "${admin_client_uuid}")"
  [ -n "$service_account_user_id" ] || fail "Could not resolve service account user for '${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}'"
  log "Resolved service account user id: ${service_account_user_id}"
  log "Resolving uuid for built-in client: realm-management"
  realm_mgmt_uuid="$(get_client_uuid_by_client_id "realm-management")"
  [ -n "$realm_mgmt_uuid" ] || fail "Could not resolve realm-management client uuid"
  log "Resolved realm-management uuid: ${realm_mgmt_uuid}"
  assign_realm_role_to_user_if_missing "${service_account_user_id}" "${FORWARDMEASURE_ROLE_PLATFORM_ADMIN}"
  assign_client_roles_to_user_if_missing "${service_account_user_id}" "${realm_mgmt_uuid}" "${KEYCLOAK_REALM_MGMT_ROLES}"
  log "Service account configured for: ${FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID}"
}

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

main() {
  KEYCLOAK_REALM_MGMT_ROLES="$(
    printf '%s' "${KEYCLOAK_REALM_MGMT_ROLES:-}" \
      | tr -d '[:space:]' \
      | sed 's/,\+/,/g; s/^,//; s/,$//'
  )"
  FORWARDMEASURE_TENANT_GROUP_ROLES="$(
    printf '%s' "${FORWARDMEASURE_TENANT_GROUP_ROLES:-}" \
      | tr -d '[:space:]' \
      | sed 's/,\+/,/g; s/^,//; s/,$//'
  )"

  require_env KEYCLOAK_URL
  require_env REALM
  require_env REALM_LOGIN_THEME
  require_env KEYCLOAK_ADMIN
  require_env KEYCLOAK_ADMIN_PASSWORD
  require_env ADMIN_USERNAME
  require_env ADMIN_EMAIL
  require_env ADMIN_FIRST_NAME
  require_env ADMIN_LAST_NAME
  require_env ADMIN_TENANT_DID
  require_env ADMIN_ACTOR_DID
  require_env ADMIN_ACTOR_TYPE
  require_env ADMIN_PASSWORD
  require_env FORWARDMEASURE_ROLE_VIEWER
  require_env FORWARDMEASURE_ROLE_ACCESS_ADMIN
  require_env FORWARDMEASURE_ROLE_PLATFORM_ADMIN
  require_env KEYCLOAK_REALM_MGMT_ROLES
  require_env FORWARDMEASURE_ADMIN_CONFIDENTIAL_CLIENT_ID
  require_env FORWARDMEASURE_ADMIN_PUBLIC_CLIENT_ID
  require_env FORWARDMEASURE_ADMIN_PUBLIC_REDIRECT_URI_1
  require_env FORWARDMEASURE_ADMIN_PUBLIC_REDIRECT_URI_2
  require_env FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_REDIRECT_URIS_JSON
  require_env FORWARDMEASURE_ADMIN_PUBLIC_WEB_ORIGIN_1
  require_env FORWARDMEASURE_ADMIN_PUBLIC_WEB_ORIGIN_2
  require_env FORWARDMEASURE_ADMIN_PUBLIC_ADDITIONAL_WEB_ORIGINS_JSON
  require_env FORWARDMEASURE_ADMIN_PUBLIC_POST_LOGOUT_REDIRECT_URIS
  require_env FORWARDMEASURE_ADMIN_PUBLIC_AUDIENCES_JSON
  require_env FORWARDMEASURE_SERVICE_CLIENTS_JSON
  require_env FORWARDMEASURE_SERVICE_CLIENT_SECRETS_DIRECTORY

  # All request paths below begin with "/". Normalise a configured root
  # context so URL joining never produces a Keycloak-rejected "//" path.
  KEYCLOAK_URL="${KEYCLOAK_URL%/}"

  : "${KEYCLOAK_READY_SLEEP_SECONDS:=5}"

  start_job_session
  kc_read_retry_setting
  print_config_banner
  wait_for_keycloak
  kc_admin_login
  wait_for_realm_management_client
  configure_realm_theme
  configure_user_profile_unmanaged_attributes
  configure_platform_roles
  configure_services_roles
  configure_bootstrap_user
  configure_tenant_administrators
  configure_organization_claim
  configure_admin_confidential_service_account
  configure_client_scopes
  configure_service_clients
  configure_public_client_redirects
  configure_public_client_audiences

  log_section "Bootstrap provisioning complete"
}

main "$@"
