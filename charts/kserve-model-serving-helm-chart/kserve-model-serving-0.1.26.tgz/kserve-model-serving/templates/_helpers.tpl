{{/*
Expand the name of the chart.
*/}}
{{- define "kserve-model-serving.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
vLLM runtime image reference resolver.
digest takes precedence over tag.
*/}}
{{- define "kserve-model-serving.vllmImageRef" -}}
{{- $repository := .Values.vllmRuntime.image.repository -}}
{{- $digest := .Values.vllmRuntime.image.digest | default "" -}}
{{- if $digest -}}
{{- printf "%s@%s" $repository $digest -}}
{{- else -}}
{{- printf "%s:%s" $repository (.Values.vllmRuntime.image.tag | default "latest") -}}
{{- end -}}
{{- end }}

{{/*
Stable cache subdirectory for a model revision.
Revision-specific paths prevent an update from mutating weights used by an
older serving revision.
*/}}
{{- define "kserve-model-serving.modelSubdir" -}}
{{- $repo := .huggingFaceRepo | replace "/" "--" -}}
{{- if .huggingFaceRevision -}}
{{- printf "%s--%s" $repo .huggingFaceRevision -}}
{{- else -}}
{{- $repo -}}
{{- end -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kserve-model-serving.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kserve-model-serving.labels" -}}
helm.sh/chart: {{ printf "%s-%s" (include "kserve-model-serving.name" .) .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "kserve-model-serving.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
ServiceAccount name resolver.
When externalModelCache is true, prefer per-model override, then
modelCache.serviceAccountName, then chart-level serviceAccount.name.
*/}}
{{- define "kserve-model-serving.serviceAccountName" -}}
{{- if and (hasKey .model "modelCache") (hasKey .model.modelCache "serviceAccountName") (.model.modelCache.serviceAccountName) -}}
{{- .model.modelCache.serviceAccountName -}}
{{- else if .Values.modelCache.serviceAccountName -}}
{{- .Values.modelCache.serviceAccountName -}}
{{- else -}}
{{- .Values.serviceAccount.name -}}
{{- end -}}
{{- end }}

{{/*
PVC name resolver.
Prefer per-model override, then chart-level modelCache.pvcName.
*/}}
{{- define "kserve-model-serving.pvcName" -}}
{{- if and (hasKey .model "modelCache") (hasKey .model.modelCache "pvcName") (.model.modelCache.pvcName) }}
{{- .model.modelCache.pvcName }}
{{- else }}
{{- .Values.modelCache.pvcName }}
{{- end }}
{{- end }}

{{/*
Skip manifest verification resolver.
Prefer per-model override, then chart-level modelCache.skipManifestVerification.
*/}}
{{- define "kserve-model-serving.skipVerification" -}}
{{- if and (hasKey .model "modelCache") (hasKey .model.modelCache "skipManifestVerification") }}
{{- .model.modelCache.skipManifestVerification | toString }}
{{- else }}
{{- .Values.modelCache.skipManifestVerification | toString }}
{{- end }}
{{- end }}

{{/*
Model download image resolver.
digest takes precedence over tag.
Prefer per-model override for registry/repository/tag/digest,
then chart-level modelDownload.image.
*/}}
{{- define "kserve-model-serving.downloadImage" -}}
{{- $img := .Values.modelDownload.image }}
{{- if and (hasKey .model "modelDownload") (hasKey .model.modelDownload "image") }}
{{- $img = .model.modelDownload.image }}
{{- end }}
{{- $registry := $img.registry | default "docker.io" }}
{{- $repo     := $img.repository }}
{{- $digest   := $img.digest | default "" }}
{{- if $digest }}
{{- printf "%s/%s@%s" $registry $repo $digest }}
{{- else }}
{{- printf "%s/%s:%s" $registry $repo ($img.tag | default "latest") }}
{{- end }}
{{- end }}

{{/*
Custom container image reference resolver.
digest takes precedence over tag.
Usage: include "kserve-model-serving.customImageRef" .customImage
*/}}
{{- define "kserve-model-serving.customImageRef" -}}
{{- $registry := .registry | default "docker.io" -}}
{{- $repo     := .repository -}}
{{- $digest   := .digest | default "" -}}
{{- if $digest -}}
{{- printf "%s/%s@%s" $registry $repo $digest -}}
{{- else -}}
{{- printf "%s/%s:%s" $registry $repo (.tag | default "latest") -}}
{{- end -}}
{{- end }}

{{/*
Validate chart-level settings required for external model cache mode.
*/}}
{{- define "kserve-model-serving.validateExternalModelCache" -}}
{{- if .Values.externalModelCache }}
  {{- if empty .Values.modelCache.pvcName }}
    {{- fail "modelCache.pvcName must be set when externalModelCache is true" }}
  {{- end }}
  {{- if empty .Values.modelCache.serviceAccountName }}
    {{- fail "modelCache.serviceAccountName must be set when externalModelCache is true" }}
  {{- end }}
  {{- if empty .Values.modelCache.mountPath }}
    {{- fail "modelCache.mountPath must be set when externalModelCache is true" }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Validate a model entry has required fields.
*/}}
{{- define "kserve-model-serving.validateModel" -}}
{{- if not .model.name }}
{{- fail "model entry missing required field: name" }}
{{- end }}
{{- if not .model.runtime }}
{{- fail (printf "model '%s' missing required field: runtime" .model.name) }}
{{- end }}
{{- if not .model.resources }}
{{- fail (printf "model '%s' missing required field: resources" .model.name) }}
{{- end }}
{{- if not .model.scaling }}
{{- fail (printf "model '%s' missing required field: scaling" .model.name) }}
{{- end }}

{{- if eq .model.runtime "kserve-custom" }}
  {{- if not .model.customImage }}
  {{- fail (printf "model '%s' with runtime kserve-custom missing required field: customImage" .model.name) }}
  {{- end }}
  {{- if not .model.customImage.repository }}
  {{- fail (printf "model '%s' customImage missing required field: repository" .model.name) }}
  {{- end }}
{{- else }}
  {{- if not .model.huggingFaceRepo }}
  {{- fail (printf "model '%s' missing required field: huggingFaceRepo" .model.name) }}
  {{- end }}
{{- end }}

{{- if or (ne .model.runtime "kserve-custom") .Values.externalModelCache }}
  {{- if not .model.huggingFaceRepo }}
  {{- fail (printf "model '%s' missing required field: huggingFaceRepo" .model.name) }}
  {{- end }}
  {{- if not .model.huggingFaceRevision }}
  {{- fail (printf "model '%s' missing required field: huggingFaceRevision" .model.name) }}
  {{- end }}
  {{- if not (regexMatch "^[0-9a-f]{40}$" (.model.huggingFaceRevision | toString)) }}
  {{- fail (printf "model '%s' huggingFaceRevision must be a full 40-character lowercase commit SHA" .model.name) }}
  {{- end }}
{{- end }}
{{- end }}
